class Start
{
public static void main(String[] args) 
{
Product s1=new Product("Alif","Pen",10,200);
s1.showDetails( );
s1. setProductId("Khan");
s1. getProductId( );
s1. setProductName("Pencil");
s1.getProductName( );
s1. setPrice(5);
s1. getPrice( );
s1. setAvailableQuantity(50);
s1. getAvailableQuantity( );
s1.showDetails( );
}
}