public class MyAlpha extends Alpha
{
	public void display()
	{
		System.out.println("Display from MyAlpha Class");
	}
}