public class Start
{
	public static void main(String args[])
	{
		Alpha a;
		MyAlpha alpha=new MyAlpha();
		Bravo b;
		MyBravo bravo=new MyBravo();
		Charlie c;
		MyCharlie charlie=new MyCharlie();
		alpha.print();
		alpha.show();
		bravo.show();
		bravo.display();
		charlie.show();
		charlie.print();
	}
}