public abstract class Alpha
{
	public void show()
	{
		System.out.println("Show from Alpha Class");
	}
	public void print()
	{
		System.out.println("Print from Alpha Class");
	}
}