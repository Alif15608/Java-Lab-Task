public class  MyCharlie extends Charlie
{
	public void print( )
	{
		System.out.println("Print from MyCharlie Class");
	}
	public void show( )
	{
		System.out.println("Show from MyCharlie Class");
	}
}