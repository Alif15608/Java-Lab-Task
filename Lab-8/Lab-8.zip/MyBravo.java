public class MyBravo extends Bravo
{
	public void display( )
	{
		System.out.println("Display from MyBravo Class");
	}
	public void show( )
	{
		System.out.println("Show from MyBravo Class");
	}
}