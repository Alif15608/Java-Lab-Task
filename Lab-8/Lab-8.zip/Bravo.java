public abstract class Bravo
{
	public abstract void show( );
	public void print( )
	{
		System.out.println("Print from Bravo Class");
	}
}