interface ScientificCalculation extends Calculation
{
	public  void Thepow(double x);
}