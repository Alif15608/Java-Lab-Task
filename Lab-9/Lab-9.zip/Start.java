public class Start{
	public static void main (String[] agrs)
	{
		ScientificCalculator sc1=new ScientificCalculator(100,200);
		
		sc1.add(100,200);
		sc1.subtract(100,200);
		sc1.multiply(100,200);
		sc1.divide(100,200);
		sc1.Thepow(100);
	}
}